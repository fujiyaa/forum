import re
import csv
from collections import defaultdict

# Читаем содержимое файла
with open(".//offtop/оффтоп - часть 18 (последняя).txt", "r", encoding="utf-8") as file:
    lines = file.readlines()

# Регулярное выражение для даты
date_pattern = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+\d{2}:\d{2}")

nickname_counts = defaultdict(int)

i = 0
while i < len(lines) - 1:
    nickname = lines[i].strip()
    date = lines[i + 1].strip()
    
    if date_pattern.fullmatch(date):
        nickname_counts[nickname] += 1
        i += 2  # Пропускаем никнейм и дату
    else:
        i += 1  # Если нет даты, двигаемся дальше

# Записываем результат в CSV
with open("output.csv", "w", newline="", encoding="utf-8") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Nickname", "Count"])
    
    for nickname, count in sorted(nickname_counts.items(), key=lambda x: x[1], reverse=True):
        writer.writerow([nickname, count])

print("Результат записан в output.csv")
