import csv
import re
from collections import Counter

def count_words(txt_file, csv_file):
    with open(txt_file, 'r', encoding='utf-8') as file:
        text = file.read().lower()
    
    words = re.findall(r'\b\w+\b', text)
    word_counts = Counter(words)
    
    with open(csv_file, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["Слово", "Частота"])
        for word, count in word_counts.most_common():
            writer.writerow([word, count])

# Пример использования
count_words('.//offtop/text.txt', 'output2.csv')